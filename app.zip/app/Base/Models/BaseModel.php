<?php

namespace Crysys\Base\Models;

use Eloquent;

class BaseModel extends Eloquent
{
}
