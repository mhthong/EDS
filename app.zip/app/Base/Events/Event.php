<?php

namespace Crysys\Base\Events;

abstract class Event
{
    //
}
