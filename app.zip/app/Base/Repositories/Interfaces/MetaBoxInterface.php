<?php

namespace Crysys\Base\Repositories\Interfaces;

use Crysys\Support\Repositories\Interfaces\RepositoryInterface;

interface MetaBoxInterface extends RepositoryInterface
{
}
