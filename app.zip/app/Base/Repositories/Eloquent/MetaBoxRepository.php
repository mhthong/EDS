<?php

namespace Crysys\Base\Repositories\Eloquent;

use Crysys\Base\Repositories\Interfaces\MetaBoxInterface;
use Crysys\Support\Repositories\Eloquent\RepositoriesAbstract;

class MetaBoxRepository extends RepositoriesAbstract implements MetaBoxInterface
{
}
