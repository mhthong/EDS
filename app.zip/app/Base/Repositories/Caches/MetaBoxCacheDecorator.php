<?php

namespace Crysys\Base\Repositories\Caches;

use Crysys\Base\Repositories\Interfaces\MetaBoxInterface;
use Crysys\Support\Repositories\Caches\CacheAbstractDecorator;

class MetaBoxCacheDecorator extends CacheAbstractDecorator implements MetaBoxInterface
{

}
