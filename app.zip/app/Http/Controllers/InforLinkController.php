<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class InforLinkController extends Controller
{
    //
}
